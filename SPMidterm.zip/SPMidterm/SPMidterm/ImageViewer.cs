﻿/* ImageViewer.cs
 * Midterm Assessment
 * Revision History:
 *      Samuel Publicover, 2021.10.22, Created, added code, debugged, and completed
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SPMidterm
{
    /// <summary>
    /// Class used to control the main form of the Image Viewer application
    /// </summary>
    public partial class ImageViewerForm : Form
    {
        /// <summary>
        /// Universal Variables: All varibale explained below
        /// </summary>
        //10 cell array used to store file names of images
        string[] imageFileNames = new string[10];
        //string used to store the file name of the currently displayed photo
        string currentImageString = "";
        //integer that stores what cell of the array the current file is located
        int currentImageInt = 0;
        //Dialog result used to determine dialog results...
        DialogResult dialogResult;

        /// <summary>
        /// Initializes the form associated with the ImageViewer class
        /// </summary>
        public ImageViewerForm()
        {
            InitializeComponent();
        }

        //Action not used
        private void imageViewerForm_Load(object sender, EventArgs e)
        {
            ////InitializeOpenFileDialog();
        }

        /// <summary>
        /// Method that recieves and array of files and a file name, and determines which cell of the array that given file is located in
        /// </summary>
        /// <param name="files">The array that holds all files</param>
        /// <param name="file">The file the user is looking for</param>
        /// <returns></returns>
        public int findCurrentFile(string[] files, string file)
        {
            //if the file is empty, return -2 (this will be used for error coding)
            if (file == null)
            {
                return -2;
            }
            //If not, loop through the array and find which cell of the array that file path is stored
            else
            {
                for (int i = 0; i < files.Length; i++)
                {
                    if (files[i] == file)
                    {
                        return i;

                    }
                }
                //Again, used for error coding
                return -1;
            }
        }

        /// <summary>
        /// When "Load Images" is selected, OpenFileDialog is ran, user can select the images they wish to display 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLoadImages_Click(object sender, EventArgs e)
        {
            //Create an instance of OpenFileDialog
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                //Check if the array for file name is full
                if (imageFileNames[imageFileNames.Length - 1] != null)
                {
                    //If full, ask if the user would like to clear it
                    dialogResult = MessageBox.Show("File capacity reached, would you like to wipe all currently saved files and upload new files?", "File Capacity Reached", MessageBoxButtons.YesNo);
                    //If yes, get the user to re-upload the images
                    if (dialogResult == DialogResult.Yes)
                    {
                        for (int i = 0; i < imageFileNames.Length; i++)
                        {
                            imageFileNames[i] = null;
                        }
                        ofd.Title = "Open Picture";
                        ofd.Filter = "jpg filed (*.jpg)|*.jpg";
                        ofd.Multiselect = true;


                        if (ofd.ShowDialog() == DialogResult.OK)
                        {


                            int i = 0;
                            foreach (String file in ofd.FileNames)
                            {
                                if (i !=imageFileNames.Length)
                                {
                                    imageFileNames[i] += file;
                                    i++;
                                }
                                else
                                {
                                    MessageBox.Show("The amount of photos uploaded surpassed the storage amount. All possible photos have been saved.", "Maximum Photos Reached");
                                }
                            }
                            //pbImageDisplay = new PictureBox();
                            Image image = new Bitmap(imageFileNames[0]);
                            pbImageDisplay.Image = new Bitmap(image, 300, 300);
                            currentImageString = imageFileNames[0];
                        }
                    }
                    //if no, exit
                    else
                    {
                        MessageBox.Show("Storage is full, no more image files can be uploaded.", "Storage Full");
                    }
                }
                //If the array isn't full, proceed to asking for the users images
                else
                {
                    //title, filter, and allow user to select multiple images at once
                    ofd.Title = "Open Picture";
                    ofd.Filter = "jpg filed (*.jpg)|*.jpg";
                    ofd.Multiselect = true;
                    //once the user has selected files, fill the array with the file paths until the array is full or until all selected files are saved in the array
                    if (ofd.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            int i = 0;
                            foreach (String file in ofd.FileNames)
                            {
                                for (int j = 0; j < imageFileNames.Length; j++)
                                {
                                    if (imageFileNames[j] == null)
                                    {
                                        imageFileNames[j] += file;
                                        break;
                                    }
                                    
                                }
                                i++;
                            }
                            //Let the user know that all file paths were successfully saved
                            MessageBox.Show("All images were successfully uploaded", "Upload Successful");
                        }
                        //The user has uploaded too many image files (the array size was surpassed)
                        catch (Exception TooManyFiles)
                        {
                            throw new Exception ("Too many files have been selected for upload or capacity has been reached", TooManyFiles);
                        }
                        //Lastly, display the first image of the array in the image box
                        //pbImageDisplay = new PictureBox();
                        //NOTE, the image is saved and then displayed in two seperate steps in order to rescale the image
                        Image image = new Bitmap(imageFileNames[0]);
                        pbImageDisplay.Image = new Bitmap(image, 300, 300);
                        currentImageString = imageFileNames[0];
                    }
                }
            }
        }

        /// <summary>
        /// The "Last" button is selected and will display the last image that was saved to the array
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLast_Click(object sender, EventArgs e)
        {
            //Check what the current image is
            currentImageInt = findCurrentFile(imageFileNames, currentImageString);
            //Check that images have actually been iploaded
            if (currentImageInt == -1 || currentImageInt == -2)
            {
                MessageBox.Show("No images have been uploaded", "Display Image Error");
            }
            //If images are uploaded, continue
            else
            {
                //If the last cell isn't empty, display its photo
                if (imageFileNames[imageFileNames.Length - 1] != null)
                {
                    Image image = new Bitmap(imageFileNames[imageFileNames.Length - 1]);
                    pbImageDisplay.Image = new Bitmap(image, 300, 300);
                    currentImageString = imageFileNames[imageFileNames.Length - 1];
                }
                //else, search through the array for the last non-null cell
                else
                {
                    for(int i = (imageFileNames.Length - 1); i > 0; i--)
                    {
                        if (imageFileNames[i] != null)
                        {
                            Image image = new Bitmap(imageFileNames[i]);
                            pbImageDisplay.Image = new Bitmap(image, 300, 300);
                            currentImageString = imageFileNames[i];
                            break;
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Displays the first image uploaded 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnFirst_Click(object sender, EventArgs e)
        {
            //check if images were uploaded
            currentImageInt = findCurrentFile(imageFileNames, currentImageString);
            if (currentImageInt == -1 || currentImageInt == -2)
            {
                MessageBox.Show("No images have been uploaded", "Display Image Error");
            }
            //if images were uploaded, display the first cell of the array
            else
            {
                Image image = new Bitmap(imageFileNames[0]);
                pbImageDisplay.Image = new Bitmap(image, 300, 300);
                currentImageString = imageFileNames[0];
            }
        }
        /// <summary>
        /// Displays the image that is previous to the current image. If the current image is the first cell of the array, shows the last saved image
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPrevious_Click(object sender, EventArgs e)
        {
            //check that images were uploaded
            currentImageInt = findCurrentFile(imageFileNames, currentImageString);
            if (currentImageInt == -1 || currentImageInt == -2)
            {
                MessageBox.Show("No images have been uploaded", "Display Image Error");
            }
            //if so, continue
            else
            {
                //Try to display the previous image (if the current image is the 1st cell of the array, then continue to catch)
                try
                {
                    Image image = new Bitmap(imageFileNames[currentImageInt - 1]);
                    pbImageDisplay.Image = new Bitmap(image, 300, 300);
                    currentImageString = imageFileNames[currentImageInt - 1];
                }
                //Loop back and basically just run btnLast
                catch (Exception)
                {
                    if (imageFileNames[imageFileNames.Length - 1] != null)
                    {
                        Image image = new Bitmap(imageFileNames[imageFileNames.Length - 1]);
                        pbImageDisplay.Image = new Bitmap(image, 300, 300);
                        currentImageString = imageFileNames[imageFileNames.Length - 1];
                    }
                    else
                    {
                        for (int i = (imageFileNames.Length - 1); i > 0; i--)
                        {
                            if (imageFileNames[i] != null)
                            {
                                Image image = new Bitmap(imageFileNames[i]);
                                pbImageDisplay.Image = new Bitmap(image, 300, 300);
                                currentImageString = imageFileNames[i];
                                break;
                            }
                        }
                    }
                }
            }
        }
        /// <summary>
        /// Displays the next image in the array. If the current image is the last image, display the first
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnNext_Click(object sender, EventArgs e)
        {
            //check that images were uploaded
            currentImageInt = findCurrentFile(imageFileNames, currentImageString);
            if (currentImageInt == -1 || currentImageInt == -2)
            {
                MessageBox.Show("No images have been uploaded", "Display Image Error");
            }
            //try to display the next image, if not, display the first
            else
            {
                try
                {
                    Image image = new Bitmap(imageFileNames[currentImageInt + 1]);
                    pbImageDisplay.Image = new Bitmap(image, 300, 300);
                    currentImageString = imageFileNames[currentImageInt + 1];
                }
                catch (Exception)
                {
                    Image image = new Bitmap(imageFileNames[0]);
                    pbImageDisplay.Image = new Bitmap(image, 300, 300);
                    currentImageString = imageFileNames[0];
                    
                }
            }
        }
        /// <summary>
        /// The image control is set to automatic, respective buttons are displayed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAutomatic_Click(object sender, EventArgs e)
        {
            //Make all necessary buttons visible/invisible
            btnPlay.Visible = true;
            btnStop.Visible = true;
            btnFirst.Visible = false;
            btnPrevious.Visible = false;
            btnNext.Visible = false;
            btnLast.Visible = false;
        }
        /// <summary>
        /// The image control is set to manual, respective buttons displayed, AND timer stopped in case
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnManual_Click(object sender, EventArgs e)
        {
            btnPlay.Visible = false;
            btnStop.Visible = false;
            btnFirst.Visible = true;
            btnPrevious.Visible = true;
            btnNext.Visible = true;
            btnLast.Visible = true;
            //Stop timer just in case
            imageTime.Stop();
        }
        /// <summary>
        /// images are displayed in slideshow format, one second intervals
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPlay_Click(object sender, EventArgs e)
        {
            
            currentImageInt = findCurrentFile(imageFileNames, currentImageString);
            if (currentImageInt == -1 || currentImageInt == -2)
            {
                MessageBox.Show("No images have been uploaded", "Display Image Error");
            }
            else
            {
                imageTime.Start();
                Image image = new Bitmap(imageFileNames[0]);
                pbImageDisplay.Image = new Bitmap(image, 300, 300);
                currentImageString = imageFileNames[0];
            }
        }
        /// <summary>
        /// The display slideshow stops, a.k.a. the timer stops
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStop_Click(object sender, EventArgs e)
        {
            imageTime.Stop();
        }
        /// <summary>
        /// Fires and action(the display of the next image) each time the timer ticks, every 1000ms
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void imageTime_Tick(object sender, EventArgs e)
        {
            try
            {
                currentImageInt = findCurrentFile(imageFileNames, currentImageString);
                Image image = new Bitmap(imageFileNames[currentImageInt + 1]);
                pbImageDisplay.Image = new Bitmap(image, 300, 300);
                currentImageString = imageFileNames[currentImageInt + 1];
            }
            catch (Exception)
            {
                Image image = new Bitmap(imageFileNames[0]);
                pbImageDisplay.Image = new Bitmap(image, 300, 300);
                currentImageString = imageFileNames[0];

            }
        }
    }
}
