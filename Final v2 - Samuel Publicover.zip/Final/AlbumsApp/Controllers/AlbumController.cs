﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

using AlbumsApp.Models;
using AlbumsApp.Models.ViewModels;
using Microsoft.AspNetCore.Http;

namespace AlbumsApp.Controllers
{
    public class AlbumController : Controller
    {
        public AlbumController(AlbumsDbContext albumsDbContext)
        {
            _albumsDbContext = albumsDbContext;
        }

        [Route("/")]
        public IActionResult List(string? count)
        {
            //Cookie counts how many times user has visited the page
            if (HttpContext.Request.Cookies["VisitCount"] == null)
            {
                Response.Cookies.Append("VisitCount", "2");
            }
            else
            {
                var visitCount = HttpContext.Request.Cookies["VisitCount"];
                var visitCountInt = int.Parse(visitCount);
                visitCountInt++;
                Response.Cookies.Append("VisitCount", visitCountInt.ToString());
            }
            //Session counts how many times user has visited page in the current session
            if (HttpContext.Session.GetString("currentVisits") == null)
            {
                HttpContext.Session.SetString("currentVisits", "1");
            }
            else
            {
                var visits = int.Parse(HttpContext.Session.GetString("currentVisits"));
                visits++;
                HttpContext.Session.SetString("currentVisits", visits.ToString());
            }

            if (count == null)
            {
                count = "5";
                ViewData["count"] = "5";
            }
            else
            {
                ViewData["count"] = count;
            }
            var albums = _albumsDbContext.Albums.Include(a => a.Studio).OrderByDescending(a => a.YearProduced).ToList();
            return View(albums);
        }

        public async Task<IActionResult> Display(int id, string name)
        {
            ViewData["studioName"] = name;
            var albums = _albumsDbContext.Albums.Include(a => a.Studio).OrderBy(m => m.AlbumId).Where(m => m.StudioId == id).ToList();
            return View(albums);
        }

        [HttpGet]
        public IActionResult Add()
        {
            var viewModel = new AddOrEditAlbumViewModel();
            viewModel.AllStudios = GetAllStudios();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Add(AddOrEditAlbumViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _albumsDbContext.Albums.Add(viewModel);
                _albumsDbContext.SaveChanges();

                return RedirectToAction("List", "Album");
            }
            else
            {
                ModelState.AddModelError("", "There were errors in the form - please fix them and try adding again.");
                viewModel.AllStudios = GetAllStudios();
                return View(viewModel);
            }
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            AddOrEditAlbumViewModel viewModel = new AddOrEditAlbumViewModel(_albumsDbContext.Albums.Include(a => a.Studio).Where(a => a.AlbumId == id).FirstOrDefault());
            viewModel.AllStudios = GetAllStudios();
            return View(viewModel);
        }

        [HttpPost]
        public IActionResult Edit(AddOrEditAlbumViewModel viewModel)
        {
            if (ModelState.IsValid)
            {
                _albumsDbContext.Albums.Update(viewModel);
                _albumsDbContext.SaveChanges();

                return RedirectToAction("List", "Album");
            }
            else
            {
                ModelState.AddModelError("", "There were errors in the form - please fix them and try updating again.");
                viewModel.AllStudios = GetAllStudios();
                return View(viewModel);
            }
        }

        [HttpGet]
        public IActionResult DeleteConfirmation(int id)
        {
            Album album = _albumsDbContext.Albums.Include(a => a.Studio).Where(a => a.AlbumId == id).FirstOrDefault();
            return View(album);
        }

        [HttpPost]
        public IActionResult Delete(int id)
        {
            Album album = _albumsDbContext.Albums.Include(a => a.Studio).Where(a => a.AlbumId == id).FirstOrDefault();
            _albumsDbContext.Albums.Remove(album);
            _albumsDbContext.SaveChanges();

            return RedirectToAction("List", "Album");
        }

        [HttpGet("/Error")]
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private List<Studio> GetAllStudios()
        {
            return _albumsDbContext.Studios.OrderBy(s => s.Name).ToList();
        }

        private AlbumsDbContext _albumsDbContext;
    }
}
