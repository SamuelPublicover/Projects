﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AlbumsApp.Models
{
    public class Studio
    {
        public int StudioId { get; set; }

        [Required]
        [StringLength(64, ErrorMessage ="Name cannot be more than 64 characters")]
        public string Name { get; set; }

        [Required]
        [RegularExpression(@"^http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?$", ErrorMessage = "URL must be in valid format")]
        public string Url { get; set; }

        [Required]
        public string Address { get; set; }

        [Required]
        public string City { get; set; }
        
        [Required]
        [RegularExpression(@"^[0-9]{5}$", ErrorMessage = "Zip code must be in valid US format (5 numbers)")]
        public string ZipCode { get; set; }
    }
}
