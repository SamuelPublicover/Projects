﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StockPortfolioTracker
{
    public partial class StockPortfolioTracker : Form
    {
        //Create the form
        public StockPortfolioTracker()
        {
            InitializeComponent();
        }

        //Creating and initializing variables I will use throughout the program
        string path, fileName, record;
        Boolean isAdd = true;
        StreamWriter writer;
        StreamReader reader;
        Double sharePrice, commision, totalAssetValue, totalTransValue;
        int transID, shares;
        string tickerSymbol, company, type;
        DateTime dateOfTransaction;
        Boolean foundIt = false;

        //Add/update method that will add a record, or update a previously existing one
        private void btnAddUpdate_Click(object sender, EventArgs e)
        {
            //Make sure a file is loaded in before continuing
            if (string.IsNullOrWhiteSpace(fileName))
            {
                rtbMessages.Text = "A file must be loaded";
                return;
            }
            //If a file is loaded in, continut
            else
            {
                //Set booleans and clearmessages
                isAdd = true;
                rtbMessages.Text = "";
                //Put inputs through edits
                rtbMessages.Text = Edit();
                //Create variables 
                string buySellSelection = "";
                double totalAssetValue = 0;
                double totalTransactionValue = 0;
                //We must first determine if the user is updating or adding
                if (rtbMessages.Text == "Do you wish to update?")
                {
                    if (btnBuy.Checked)
                        buySellSelection = "BUY";
                    if (btnSell.Checked)
                        buySellSelection = "SELL";
                    //Calculate totalAssetValue and totalTransactionValue
                    Double doubleSharePrice = (Double.Parse(txtSharePrice.Text));
                    Int32 doubleNumberOfShares = (Int32.Parse(txtNumberOfShares.Text));
                    Double doubleCommision = (Double.Parse(txtCommision.Text));
                    //Calculate the totalAssetValue and the totalTransactionValue
                    totalAssetValue = (doubleSharePrice * doubleNumberOfShares);
                    totalTransactionValue = totalAssetValue - doubleCommision;
                    //Ask if the user actually wants to update this one
                    DialogResult updateConfirmation = MessageBox.Show("The entered transactionID already exists. Would you like to update the record?", "Update Record's Contents?", MessageBoxButtons.YesNo);
                    //If the user actually wants to update the record, continue
                    if (updateConfirmation == DialogResult.Yes)
                    {
                        //make the txtDelete field equal to the txtTrandID field, then delete that TransID
                        txtDeleteID.Text = txtTransID.Text;
                        btnDeleteTransaction_Click(sender, e);
                        //If the record is successfully deleted, continue
                        if (rtbMessages.Text == "Record deleted successfully")
                        {
                            //Update the record, using their respective variables
                            record = $"{txtTransID.Text}\t{txtTicker.Text}\t{txtCompany.Text}\t{buySellSelection}\t{dtpDate.Value.ToString()}\t{txtSharePrice.Text}\t{txtNumberOfShares.Text}\t{txtCommision.Text}\t{totalAssetValue}\t{totalTransactionValue}";
                            try
                            {
                                using (writer = new StreamWriter(fileName, append: true))
                                {
                                    writer.WriteLine(record);
                                }
                                rtbMessages.Text = "transaction updated";
                            }
                            catch (Exception ex)
                            {
                                rtbMessages.Text = "exception adding new transaciton: " + ex.Message;
                            }
                            if (rtbMessages.Text == "transaction updated")
                                rtbMessages.Text = "record updated";
                        }
                    }
                    else
                    {
                        rtbMessages.Text = "Update Cancelled";
                    }
                }
                //If rtbMessages is clear, then the file doesn't already exist, and t must be added rather than updated
                if (rtbMessages.Text == "")
                {
                    //Determine which radio button is selected
                    if (btnBuy.Checked)
                        buySellSelection = "BUY";
                    if (btnSell.Checked)
                        buySellSelection = "SELL";
                    //Calculate totalAssetValue and totalTransactionValue
                    Double doubleSharePrice = (Double.Parse(txtSharePrice.Text));
                    Int32 doubleNumberOfShares = (Int32.Parse(txtNumberOfShares.Text));
                    Double doubleCommision = (Double.Parse(txtCommision.Text));
                    totalAssetValue = (doubleSharePrice * doubleNumberOfShares);
                    totalTransactionValue = totalAssetValue - doubleCommision;
                    //Create the record using it respective variables
                    record = $"{txtTransID.Text}\t{txtTicker.Text}\t{txtCompany.Text}\t{buySellSelection}\t{dtpDate.Value.ToString()}\t{txtSharePrice.Text}\t{txtNumberOfShares.Text}\t{txtCommision.Text}\t{totalAssetValue}\t{totalTransactionValue}";
                    try
                    {
                        using (writer = new StreamWriter(fileName, append: true))
                        {
                            writer.WriteLine(record);
                        }
                        rtbMessages.Text = "transaction added";
                    }
                    catch (Exception ex)
                    {
                        rtbMessages.Text = "exception adding new transaciton: " + ex.Message;
                    }
                }
            }
        }

        //Holds all possible errors for inputs to avoid future
        private string Edit()
        {
            //Clear all errors
            string errors = "";


            //ERRORS FOR TRANSACTION ID
            //Transaction ID can't be empty of blank
            if (String.IsNullOrWhiteSpace(txtTransID.Text))
            {
                if (errors == "") txtTransID.Focus();
                errors += "a non-blank transactionID is required\n";
            }
            //Transaction ID must be an integer
            else if (!Int32.TryParse(txtTransID.Text, out transID))
            {
                if (errors == "") txtTransID.Focus();
                errors += "transactionID is not an integer number\n";
            }
            //Transaction ID can't be a negative or equal to zero
            else if (transID <= 0)
            {
                if (errors == "") txtTransID.Focus();
                errors += "transactionID must be an integer greater than zero\n";
            }
            //Check if the ID already exists
            else
            {
                foundIt = false;
                //Read through the .txt file to see if the transaction ID is already on file
                using (reader = new StreamReader(fileName))
                {
                    //While the reader isn't at the end of the stream, continue
                    while (!reader.EndOfStream)
                    {
                        //Store the currently read line in string - "record"
                        record = reader.ReadLine();
                        //If the current line starts with the transaction ID that was entered...
                        if (record.StartsWith(txtTransID.Text + "\t"))
                        {
                            //Store in boolean that transID has been found
                            foundIt = true;
                            break;
                        }
                    }
                    //If user was trying to add but ID already exists, output an error
                    if (foundIt)
                    {
                        if (errors == "") txtTransID.Focus();
                        errors += "transactionID is already on file ... did you intend an update?\n";
                    }
                    //If user was trying to update, BUT it WASN'T found, output an error
                    else if (!isAdd && !foundIt)
                    {
                        if (errors == "") txtTransID.Focus();
                        errors += "transactionID being updated is not on file\n";
                    }
                }
            }

            
            //ERRORS FOR TICKER SYMBOL
            if (String.IsNullOrWhiteSpace(txtTicker.Text))
            {
                if (errors == "") txtTicker.Focus();
                errors += "a non-blank ticker symbol is required\n";
            }
            txtTicker.Text.Trim();


            //ERRORS FOR COMPANY NAME
            if (String.IsNullOrWhiteSpace(txtCompany.Text))
            {
                if (errors == "") txtCompany.Focus();
                errors += "a non-blank company name is required\n";
            }
            //The following is for formatting purposes
            if (txtCompany.Text.Length < 7)
                txtCompany.Text += "     ";
            if (txtCompany.Text.Length < 4)
                txtCompany.Text += "       ";
            txtCompany.Text.Trim();
            rtbNotes.Text.Trim();

            //ERRORS FOR BUY/SELL SELECTION
            if (!btnBuy.Checked && !btnSell.Checked)
            {
                errors += "Must select a transaction type\n";
            }

            //ERRORS FOR DATE (date can't be greater than current day)
            if (dtpDate.Value > DateTime.Now)
            {
                if (errors == "") dtpDate.Focus();
                errors += "date of transaction cannot be in the future\n";
            }


            //ERRORS FOR SHARE PRICE
            //Share price must be entered
            if (String.IsNullOrWhiteSpace(txtSharePrice.Text))
            {
                if (errors == "") txtSharePrice.Focus();
                errors += "a non-blank share price is required\n";
            }
            //Share price must be an number
            else if (!Double.TryParse(txtSharePrice.Text, out sharePrice))
            {
                if (errors == "") txtSharePrice.Focus();
                errors += "share price is not a number\n";
            }
            //Share price can't be a negative or equal to zero
            else if (sharePrice <= 0)
            {
                if (errors == "") txtSharePrice.Focus();
                errors += "share price must be a number greater than zero\n";
            }


            //ERRORS FOR # OF SHARES
            if (String.IsNullOrWhiteSpace(txtNumberOfShares.Text))
            {
                if (errors == "") txtNumberOfShares.Focus();
                errors += "a non-blank share amount is required\n";
            }
            //# of shares must be an number (A trader is able to my fractions of shares however, therefore decimals are allowed)
            else if (!Int32.TryParse(txtNumberOfShares.Text, out shares))
            {
                if (errors == "") txtNumberOfShares.Focus();
                errors += "shares amount is not a number\n";
            }
            //# of shares can't be a negative or equal to zero
            else if (shares <= 0)
            {
                if (errors == "") txtNumberOfShares.Focus();
                errors += "shares amount must be a number greater than zero\n";
            }

            //ERRORS FOR COMMISION
            if (String.IsNullOrWhiteSpace(txtCommision.Text))
            {
                if (errors == "") txtCommision.Focus();
                errors += "a non-blank commision price is required\n";
            }
            //Share price must be an number
            else if (!Double.TryParse(txtCommision.Text, out sharePrice))
            {
                if (errors == "") txtCommision.Focus();
                errors += "commision value is not a number\n";
            }
            //Share price can't be a negative or equal to zero
            else if (commision <= 0)
            {
                if (errors == "") txtCommision.Focus();
                errors += "commision price must be a number greater than zero\n";
            }

            //If trans ID isn't on file, add

            //If there were no errors, but the ID already existed, ask the user if they wanted to update the file
            if (errors == "transactionID is already on file ... did you intend an update?\n")
                errors = "Do you wish to update?";
            //rtbMessages.Text = errors;
            return errors;
        }

        //The DeleteTransaction method deletes an existing record, using the entered transaction ID
        private void btnDeleteTransaction_Click(object sender, EventArgs e)
        {
            //First, verify that a file is loaded before user can use this button
            if (string.IsNullOrWhiteSpace(fileName))
            {
                rtbMessages.Text = "A file must be loaded";
                return;
            }
            //If the file is loaded, continue
            else
            {
                List<string> records = new List<string>();
                foundIt = false;
                //create an instance of a reader, read through the file and see if the given record does actually exist, and set the boolean to true if found
                using (reader = new StreamReader(fileName))
                {
                    while (reader.EndOfStream == false)
                    {
                        record = reader.ReadLine();
                        if (record.StartsWith(txtDeleteID.Text + "\t"))
                        {
                            foundIt = true;
                        }
                        else
                            records.Add(record);
                    }
                }
                //If the variable is still false at the end, no record was found
                if (!foundIt)
                {
                    rtbMessages.Text = "Record ID not found";
                    return;
                }
                //If the variable isn't false, try deleting it
                try
                {
                    //Create a streamwriter that writes over and deletes the record that was entered.
                    using (writer = new StreamWriter(fileName, append: false))
                    {
                        foreach (var item in records)
                        {
                            writer.WriteLine(item);
                        }
                    }
                    //Output that the record was successfuly deleted
                    rtbMessages.Text = "Record deleted successfully";
                }
                //If there was an error throughout the try, return the exception to the user
                catch (Exception ex)
                {
                    rtbMessages.Text = "exception deleting record: " + ex.Message;
                }
            }
        }

        //New ID Button: Goes through the saved file to find the next available TransactionID
        private void btnGetNewID_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(fileName))
            {
                rtbMessages.Text = "A file must be loaded";
                return;
            }
            else
            {
                try
                {
                    //Create variables to hold the next available int (as well as a string to display in the txtTransID.Text
                    Int32 nextAvailableInt = 1;
                    string nextAvailableIntString = "";
                    foundIt = true;
                    //Read the file
                    using (reader = new StreamReader(fileName))
                    {
                        //Read until the end (OR the loop breaks)
                        while (reader.EndOfStream == false)
                        {

                            //IF the reader has gone through andhasn't found the given variable, break and store the current available integer in txtTransID.Text
                            if (!foundIt)
                                break;

                            record = reader.ReadLine();
                            //If the current line starts with that same number that's held in the nextAvaiableInt variable, keep going
                            if (record.StartsWith(nextAvailableInt + "\t"))
                            {
                                foundIt = true;
                                nextAvailableInt += 1;
                            }
                            //If the current line DOES NOT start with that same number that's held in the nextAvaiableInt variable, set foundIt to false (THIS WILL BREAK THE LOOP)
                            else
                                foundIt = false;
                        }
                        //Store the available integer as a string (this way it can be easily put into the textbox)
                        nextAvailableIntString = nextAvailableInt.ToString();
                        //Input the final saved value for NextAvailableInt into the txtTransID.Text field
                        txtTransID.Text = nextAvailableIntString;
                    }
                }
                catch (Exception ex)
                {
                    rtbMessages.Text = "Exception find new TransID: " + ex.Message;
                }
            }
        }

        //Empty the file
        private void btnEmptyFile_Click(object sender, EventArgs e)
        {
            //Make sure a file is actually loaded before letting the user use this button
            if (string.IsNullOrWhiteSpace(fileName))
            {
                rtbMessages.Text = "A file must be loaded";
                return;
            }
            //If a file has been loaded, recreate it (overwrite the original basically, which produces the same file, but now clearer)
            else
            {
                File.Create(fileName).Close();
            }
        }

        //Closes the form
        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }


        //The clear method clears all of the fields
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtTransID.Text = "";
            txtTicker.Text = "";
            txtCompany.Text = "";
            txtSharePrice.Text = "";
            btnBuy.Checked = false;
            btnSell.Checked = false;
            txtNumberOfShares.Text = "";
            txtCommision.Text = "";

        }

        //Open a file or create a file
        private void btnOpenCreate_Click(object sender, EventArgs e)
        {
            //Clear the display and error messages
            rtbMessages.Text = "";
            rtbDisplay.Text = "";
            //Regex created to make the user enters in a .txt file
            Regex validTextFile = new Regex(@"([.]txt)$");
            //Check to make sure entry matches the rege
            if (validTextFile.IsMatch(txtFileName.Text))
            {
                
                if (!File.Exists(txtFileName.Text))
                {
                    path = Path.GetDirectoryName(txtFileName.Text);
                    fileName = Path.GetFileName(txtFileName.Text);
                    if (!string.IsNullOrWhiteSpace(path))
                    {
                        if (!Directory.Exists(path))
                            Directory.CreateDirectory(path);
                    }
                    File.Create(txtFileName.Text).Dispose();
                }
                fileName = txtFileName.Text;
                //Once the file is properly pulled up/created, display what's in the file (if empty, only the heading will be displayed
                btnDisplay_Click(sender, e);
            }
            else
            {
                rtbMessages.Text = "File Name Error: A valid .txt file must be entered";
            }
        }

        //Display the records in the file
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            rtbMessages.Text = "";
            //Make sure a file is opened before continuing
            if (string.IsNullOrWhiteSpace(fileName))
            {
                rtbMessages.Text = "A file must be loaded";
                return;
            }
            //If a file is open, continue
            else
            {
                //Display at the top of the document, the following headings
                rtbDisplay.Text = $"TransactionID\tTickerSymbol\tCompany\t\tType\t\tDate\tSharePrice\t#Shares\t\tCommision\tTotalAssetValue\t\tTotalTransactionValue\n";
                //Using streamreader, until the end of document is reached, read each record (row), parse it to it's respected data type, and display the records info
                using (reader = new StreamReader(fileName))
                {
                    while (!reader.EndOfStream)
                    {
                        record = reader.ReadLine();
                        Parse();
                        rtbDisplay.Text += $"{transID.ToString()}\t\t" +
                            $"{tickerSymbol}\t\t" +
                            $"{company}\t\t" +
                            $"{type}\t" +
                            $"{dateOfTransaction.ToString("yyyy MMM dd")}\t" +
                            $"{sharePrice.ToString("C")}\t\t" +
                            $"{shares.ToString()}\t\t" +
                            $"{commision.ToString("C")}\t\t" +
                            $"{totalAssetValue.ToString("C")}\t\t\t" +
                            $"{totalTransValue.ToString("C")}\n";
                    }
                }
            }
        }

        //This parse method splits the entered record into the respective 10 fields, and converts the data type from string to its needed type
        private void Parse()
        {
            string[] fields = record.Split('\t');
            transID = Convert.ToInt32(fields[0]);
            tickerSymbol = (fields[1]);
            company = (fields[2]);
            type = (fields[3]);
            dateOfTransaction = Convert.ToDateTime(fields[4]);
            sharePrice = Convert.ToDouble(fields[5]);
            shares = Convert.ToInt32(fields[6]);
            commision = Convert.ToDouble(fields[7]);
            totalAssetValue = Convert.ToDouble(fields[8]);
            totalTransValue = Convert.ToDouble(fields[9]);
        }
    }
}
